#!/bin/sh

source /etc/init.d/ulog_functions.sh

case "$1" in
  stop)
    ulog dropbear "stopping ssh server"
    kill `cat /var/run/dropbear.pid`
    ;;
  *)
    ulog dropbear "starting ssh server"
    /opt/sbin/dropbear -p `syscfg get lan_ipaddr`:22
    ;;
esac
